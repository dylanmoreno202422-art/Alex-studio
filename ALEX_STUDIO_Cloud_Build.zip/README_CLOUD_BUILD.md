# ALEX STUDIO — compilación en la nube desde Android

Este proyecto puede compilarse usando GitHub Actions sin instalar Android Studio ni el SDK en tu teléfono.

## Pasos desde el celular

1. Descarga y descomprime `ALEX_STUDIO_Cloud_Build.zip` con la app Archivos de Android.
2. En el navegador, abre https://github.com y crea una cuenta o inicia sesión.
3. Crea un repositorio nuevo llamado `alex-studio` y déjalo como **Public** (para evitar límites de minutos de Actions en algunos planes; si prefieres privado, revisa los límites de tu cuenta).
4. Sube el contenido de esta carpeta al repositorio, manteniendo la carpeta `.github/workflows/build-apk.yml` en esa ruta. En la web de GitHub puedes usar **Add file → Upload files**; si la subida de carpetas ocultas es difícil desde móvil, activa “sitio para ordenador” en el navegador.
5. Cuando termines de subir los archivos a la rama `main`, abre la pestaña **Actions**. El flujo “Build ALEX STUDIO APK” debería comenzar automáticamente.
6. Espera a que termine en verde. Abre esa ejecución y baja el artefacto **ALEX-STUDIO-APK**.
7. Descomprime el artefacto y toca `app-debug.apk` para instalarlo. Android podría pedirte que permitas instalar aplicaciones desde esa fuente.

## Importante
- Esta compilación produce un APK de depuración para pruebas, no una publicación firmada para Play Store.
- No compartas credenciales ni claves privadas.
- La compilación depende de GitHub Actions y de que GitHub acepte y termine el flujo.
