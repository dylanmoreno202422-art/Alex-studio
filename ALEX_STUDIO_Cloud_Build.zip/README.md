# ALEX STUDIO — Proyecto Android

Esta carpeta contiene el proyecto fuente de una app Android con interfaz horizontal y el estudio musical web integrado como recurso local.

## Crear la APK
1. Instala Android Studio en un computador.
2. Abre la carpeta `AlexStudioAndroid` desde Android Studio.
3. Espera a que Gradle sincronice y descarga los componentes del SDK si los solicita.
4. Ve a **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. La APK de depuración se genera normalmente en `app/build/outputs/apk/debug/app-debug.apk`.

## Instalar en el teléfono
Transfiere `app-debug.apk` al Android y ábrelo. Si Android lo pide, autoriza la instalación para la aplicación usada para abrir el archivo.

## Qué incluye
- Interfaz forzada en horizontal.
- Secuenciador de 16 pasos, batería y bajo sintetizados.
- Piano roll básico.
- Vista de arreglo, controles de mezcla y procesamiento dinámico básico.
- Exportación/importación de proyectos JSON.

## Limitaciones honestas
Este prototipo no incluye aún grabación multipista de voz, samples comerciales, plugins VST, Auto-Tune real ni renderizado de mezcla a WAV/MP3. La masterización es básica y no garantiza un máster comercial. La APK no se ha compilado aquí; este paquete es el proyecto fuente para construirla en Android Studio.
